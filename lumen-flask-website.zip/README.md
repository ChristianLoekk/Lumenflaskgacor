# LUMEN-FLASK | Minimalist Matte Tumbler Website

Website katalog produk **LUMEN-FLASK Matte Tumbler** lengkap dengan video iklan pembuka (*intro ad*), daftar keunggulan produk, tabel spesifikasi teknis, pilihan varian warna matte interaktif, serta informasi kontak.

## Struktur Folder
```text
├── index.html
├── style.css
├── script.js
└── assets/
    ├── promo-ad.mp4      (Video iklan pembuka 10 detik)
    ├── logo.png          (Logo LUMEN-FLASK)
    ├── tumbler-hero.jpg  (Foto utama produk)
    └── tumbler-top.jpg   (Foto detail tutup handle produk)
```

## Cara Menjalankan
1. Masukkan file video iklan dan gambar produk ke dalam folder `assets/` sesuai nama file di atas.
2. Buka `index.html` di browser atau aktifkan **GitHub Pages** pada tab **Settings > Pages**.
