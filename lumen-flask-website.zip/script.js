// Data 9 Keunggulan Utama Produk sesuai website LUMEN-FLASK
const featuresData = [
  {
    icon: "fa-regular fa-snowflake",
    title: "Dingin Hingga 12 Jam",
    desc: "Dual-wall vacuum insulation efisien mengunci suhu, menjaga minuman favoritmu tetap dingin menyegarkan sepanjang hari."
  },
  {
    icon: "fa-solid fa-shield-halved",
    title: "Tutup Karet Silicone 100% Anti Bocor",
    desc: "Dilengkapi silicone seal lid presisi 100% anti bocor, aman disimpan di dalam tas sekolah atau ransel bersama buku."
  },
  {
    icon: "fa-solid fa-layer-group",
    title: "Scratch-Resistant Powder Coating",
    desc: "Lapisan matte powder coating tahan goresan, memberikan tampilan elegan serta daya tahan ekstra untuk pemakaian harian."
  },
  {
    icon: "fa-solid fa-grip-lines",
    title: "Desain Ergonomis (Easy Grip)",
    desc: "Desain ramping dan nyaman dipegang, dilapisi tekstur matte anti-slip sehingga tidak mudah tergelincir dari genggaman."
  },
  {
    icon: "fa-solid fa-hand-holding",
    title: "Gantungan Handle Praktis",
    desc: "Dilengkapi dengan gantungan handle yang ergonomis sehingga sangat praktis dibawa bepergian ke sekolah, kampus, maupun olahraga."
  },
  {
    icon: "fa-solid fa-flask",
    title: "Stainless Steel BPA Free",
    desc: "Terbuat dari bahan Stainless Steel berkualitas tinggi yang aman bebas BPA (BPA Free) dan bebas racun."
  },
  {
    icon: "fa-solid fa-mug-hot",
    title: "Sangat Cocok untuk Aneka Minuman",
    desc: "Sangat fleksibel dan pas untuk membawa kopi hangat, teh segar, air dingin, maupun jus buah."
  },
  {
    icon: "fa-solid fa-gift",
    title: "Polos & Estetika Simpel",
    desc: "Tampilan matte polos yang modern dan bersih, mengusung nilai kenyamanan dan keandalan tinggi bagi pelajar."
  },
  {
    icon: "fa-solid fa-box-open",
    title: "Packaging Box Eksklusif",
    desc: "Sudah dilengkapi packaging box khusus untuk tiap botol, menjamin keamanan pengiriman dan kerapihan produk."
  }
];

// Data Spesifikasi Detail Produk
const specsData = [
  { label: "Stok", value: '<span class="badge-stock">TERSEDIA</span>' },
  { label: "Merek", value: "LUMEN-FLASK" },
  { label: "Produk Olahraga", value: "Ya" },
  { label: "Fitur Utama", value: "Dual-Wall Vacuum Insulation" },
  { label: "Finishing", value: "Scratch-Resistant Powder Coating" },
  { label: "Tutup / Seal", value: "100% Leak-Proof Silicone Seal" },
  { label: "Jenis Botol Minum", value: "Termos / Vacuum Tumbler" },
  { label: "Produk Custom", value: "Tidak" },
  { label: "Bahan", value: "Stainless Steel Double Wall" },
  { label: "Kapasitas Volume", value: "850ml / 750ml" },
  { label: "Retensi Suhu Cold", value: "Hingga 12 Jam" },
  { label: "Dikirim Dari", value: "Indonesia" },
  { label: "Berat Produk", value: "380 gram" },
  { label: "Dimensi Botol", value: "Diameter 7.5 cm, Tinggi 28.5 cm" },
  { label: "Dimensi Packaging", value: "9 x 9 x 29.5 cm" }
];

document.addEventListener("DOMContentLoaded", () => {
  // === 1. LOGIKA VIDEO IKLAN PEMBUKA (INTRO AD) ===
  const adOverlay = document.getElementById("adOverlay");
  const introAdVideo = document.getElementById("introAdVideo");
  const skipAdBtn = document.getElementById("skipAdBtn");
  const adCtaBtn = document.getElementById("adCtaBtn");
  const muteToggleBtn = document.getElementById("muteToggleBtn");
  const muteIcon = document.getElementById("muteIcon");
  const adProgressFill = document.getElementById("adProgressFill");
  const replayAdBtn = document.getElementById("replayAdBtn");

  function closeAdOverlay() {
    adOverlay.classList.add("hidden");
    document.body.classList.remove("no-scroll");
    introAdVideo.pause();
  }

  function openAdOverlay() {
    adOverlay.classList.remove("hidden");
    document.body.classList.add("no-scroll");
    introAdVideo.currentTime = 0;
    introAdVideo.play().catch(() => {});
  }

  // Tutup otomatis setelah video selesai
  introAdVideo.addEventListener("ended", closeAdOverlay);

  // Update progress bar video iklan
  introAdVideo.addEventListener("timeupdate", () => {
    if (introAdVideo.duration) {
      const percent = (introAdVideo.currentTime / introAdVideo.duration) * 100;
      adProgressFill.style.width = `${percent}%`;
    }
  });

  // Tombol Lewati Iklan & Lihat Produk
  skipAdBtn.addEventListener("click", closeAdOverlay);
  adCtaBtn.addEventListener("click", closeAdOverlay);

  // Tombol Mute / Unmute Audio Video
  muteToggleBtn.addEventListener("click", () => {
    introAdVideo.muted = !introAdVideo.muted;
    muteIcon.className = introAdVideo.muted
      ? "fa-solid fa-volume-xmark"
      : "fa-solid fa-volume-high";
  });

  // Tombol Putar Ulang Iklan dari Navbar
  replayAdBtn.addEventListener("click", () => {
    openAdOverlay();
    navLinks.classList.remove("open");
  });

  // Pastikan autoplay berjalan lancar
  introAdVideo.play().catch(() => {});

  // === 2. RENDER KARTU KEUNGGULAN ===
  const featuresGrid = document.getElementById("featuresGrid");
  featuresGrid.innerHTML = featuresData.map(item => `
    <div class="feature-card">
      <div class="icon-box">
        <i class="${item.icon}"></i>
      </div>
      <div>
        <h3>${item.title}</h3>
        <p>${item.desc}</p>
      </div>
    </div>
  `).join("");

  // === 3. RENDER TABEL SPESIFIKASI ===
  const specGrid = document.getElementById("specGrid");
  specGrid.innerHTML = specsData.map(spec => `
    <div class="spec-row">
      <span class="spec-label">${spec.label}</span>
      <span class="spec-val">${spec.value}</span>
    </div>
  `).join("");

  // === 4. INTERAKSI PILIHAN WARNA MATTE ===
  const colorButtons = document.querySelectorAll(".color-pill");
  const selectedColorInfo = document.getElementById("selectedColorInfo");

  colorButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      colorButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const chosenColor = btn.getAttribute("data-color");
      selectedColorInfo.innerHTML = `Varian dipilih: <strong>${chosenColor}</strong>`;
    });
  });

  // === 5. TOGGLE MENU MOBILE ===
  const mobileMenuBtn = document.getElementById("mobileMenuBtn");
  const navLinks = document.getElementById("navLinks");

  mobileMenuBtn.addEventListener("click", () => {
    navLinks.classList.toggle("open");
  });

  navLinks.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      navLinks.classList.remove("open");
    });
  });
});
